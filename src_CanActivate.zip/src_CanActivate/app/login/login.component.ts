import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { FormBuilder, Validators } from "@angular/forms";
import { AuthService } from "../auth.service";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"]
})
export class LoginComponent implements OnInit {
  errorMsg: string;
  form;
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private auth: AuthService
  ) {
    this.form = fb.group({
      email: ["", [Validators.required, Validators.email]],
      password: ["", Validators.required]
    });
  }

  ngOnInit() {}

  // creteLogin(loginForm) {
  //   if (loginForm.email == "test@gmail.com" && loginForm.pwd == "test") {
  //     this.router.navigate(["list"]);
  //   } else {
  //     this.errorMsg = "You have entered an invalid username or password";
  //   }
  // }
  creteLogin(loginForm) {
    console.log(loginForm);
    if (loginForm.email == "test@gmail.com" && loginForm.pwd == "test") {
      this.auth.sendToken(this.form.value.email);
      this.router.navigate(["list"]);
    } else {
      this.errorMsg = "You have entered an invalid username or password";
    }
  }
}
