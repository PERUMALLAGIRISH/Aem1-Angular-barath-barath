import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.css"]
})
export class HomeComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
  alphaNumaric = "^[A-Za-z0-9_]{3,50}$";
  email = "^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$";
  numberonlyPhone = "^[0-9]{10,10}$";

  constructor(
    private formBuilder: FormBuilder,
    public toastr: ToastrService,
    private router: Router
  ) {}

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstName: [
        "",
        [Validators.required, Validators.pattern(this.alphaNumaric)]
      ],
      lastName: [
        "",
        [Validators.required, Validators.pattern(this.alphaNumaric)]
      ],
      emailAddress: ["", [Validators.required, Validators.pattern(this.email)]],
      mobileNumber: [
        "",
        [Validators.required, Validators.pattern(this.numberonlyPhone)]
      ],
      address: ["", Validators.required],
      dob: ["", Validators.required],
      panNumber: ["", Validators.required],
      numberOfDeps: ["", Validators.required],
      company: ["", Validators.required],

      typeOfEmp: ["", Validators.required],
      ctc: ["", Validators.required],
      relationship: ["", Validators.required],
      date: ["", Validators.required],
      termsAndCondition: ["", Validators.required]
    });
  }
  get getFormValue() {
    return this.registerForm.controls;
  }
  registerUser() {
    this.submitted = true;
    var available = false;

    let genderId;
    var genderValue = false;
    let maritalId;
    var maritalValue = false;
    genderId = document.getElementsByName("gender");
    for (var i = 0; i < genderId.length; i++) {
      if (genderId[i].checked == true) {
        genderValue = true;
      }
    }
    if (!genderValue) {
      document.getElementById("genderError").style.display = "block";
    }

    maritalId = document.getElementsByName("marital");
    for (var i = 0; i < maritalId.length; i++) {
      if (maritalId[i].checked == true) {
        maritalValue = true;
      }
    }
    if (!maritalValue) {
      document.getElementById("maritalError").style.display = "block";
    }

    //stop here if form is invalid
    if (this.registerForm.invalid) {
      return;
    }
    console.log(this.registerForm.value);
    this.toastr.success("Welcome", "You Have successfully Registered");
  }
  disableGenderError() {
    document.getElementById("genderError").style.display = "none";
  }
  disableMaritalError() {
    document.getElementById("maritalError").style.display = "none";
  }
}
