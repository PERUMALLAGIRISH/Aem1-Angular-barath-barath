export interface Request {
  requestId: string;
  firstname: string;
  lastname: string;
  date: string;
  status: string;
  manager: string;
  country: string;
  state: string;
  zipcode: string;
  email: string;
}
