import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { HomeComponent } from "./home/home.component";
import { LoginComponent } from "./login/login.component";
import { RequestComponent } from "./request/request.component";
import { ManagerComponent } from "./manager/manager.component";
import { UserDetailComponent } from "./user-detail/user-detail.component";
import { RetailComponent } from "./retail/retail.component";
import { InsuranceComponent } from "./insurance/insurance.component";
import { AutomobileComponent } from "./automobile/automobile.component";
import { TestComponent } from "./test/test.component";

const routes: Routes = [
  { path: "", component: HomeComponent },
  { path: "login", component: LoginComponent },
  { path: "admin", component: RequestComponent },
  { path: "manager", component: ManagerComponent },
  { path: "user", component: UserDetailComponent },
  { path: "retail", component: RetailComponent },
  { path: "insurance", component: InsuranceComponent },
  { path: "automobile", component: AutomobileComponent },
  { path: "test", component: TestComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
