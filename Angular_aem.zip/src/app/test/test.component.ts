import { Component, OnInit } from "@angular/core";
import { HttpClient } from "@angular/common/http";

@Component({
  selector: "app-test",
  templateUrl: "./test.component.html",
  styleUrls: ["./test.component.css"]
})
export class TestComponent implements OnInit {
  constructor(private http: HttpClient) {}

  httpdata;
  // ngOnInit() {
  //   this.http
  //     .get("http://jsonplaceholder.typicode.com/users")
  //     .subscribe(data => this.displaydata(data));
  // }
  // displaydata(data) {
  //   this.httpdata = data;
  // }
  ngOnInit() {
    this.http
      .get("http://jsonplaceholder.typicode.com/users")
      .subscribe(data => {
        this.httpdata = data;
        console.log(this.httpdata, "get Medical Summary Details.");
      });
  }
}
