import { Component, OnInit, ViewChild } from "@angular/core";
import {
  MatDialog,
  MatDialogRef,
  MatDialogConfig,
  MatTableDataSource
} from "@angular/material";
import { RequestService } from "src/app/request/request.service";
import { Request } from "../request/request";
import { FilterComponent } from "src/app/filter/filter.component";
import { UserDetailComponent } from "src/app/user-detail/user-detail.component";
import { ToastrService } from "ngx-toastr";
@Component({
  selector: "app-manager",
  templateUrl: "./manager.component.html",
  styleUrls: ["./manager.component.css"]
})
export class ManagerComponent implements OnInit {
  displayedColumns: string[] = [
    "requestId",
    "fname",
    "lname",
    "date",
    "status",
    "country",
    "state",
    "zipcode",
    "email"
  ];
  dataSource: MatTableDataSource<Request>;
  filterData: MatTableDataSource<Request>;

  constructor(
    private RequestService: RequestService,
    private dialog: MatDialog,
    public toastr: ToastrService
  ) {
    this.RequestService.getList().subscribe(data => {
      const users = data;
      //console.log(users);
      this.dataSource = new MatTableDataSource(users);
    });
  }

  ngOnInit() {
    document.getElementById("banner").style.backgroundImage =
      "url(../../assets/images/Header.jpg)";
  }

  openDialog() {
    localStorage.setItem("manager", "1");
    const dialogConfig = new MatDialogConfig();
    const dialog = this.dialog.open(FilterComponent, dialogConfig);
    // Create subscription
    dialog.afterClosed().subscribe(data => {
      // Do stuff after the dialog has closed
      console.log(data);
      if (data["status"].trim().toLowerCase() != "status") {
        this.dataSource.filter = data["status"].trim().toLowerCase();
        // this.dataSource = new MatTableDataSource(this.dataSource.filteredData);
        //console.log(this.dataSource);
        // this.dataSource.filter = data["manager"].trim().toLowerCase();
        //console.log(this.dataSource);
      }
    });
    // Return dialog object
    return dialog;
  }
  openDetail() {
    const dialogConfig = new MatDialogConfig();
    const dialog = this.dialog.open(UserDetailComponent, dialogConfig);
    // Create subscription
    dialog.afterClosed().subscribe(data => {
      this.toastr.success("Welcome", "You Have successfully Registered");
    });
    // Return dialog object
    return dialog;
  }
}
