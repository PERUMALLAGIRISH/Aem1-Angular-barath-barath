import { Component, OnInit } from "@angular/core";
import { MatDialogRef } from "@angular/material";

@Component({
  selector: "app-filter",
  templateUrl: "./filter.component.html",
  styleUrls: ["./filter.component.css"]
})
export class FilterComponent implements OnInit {
  manager: string;
  constructor(public dialogRef: MatDialogRef<FilterComponent>) {}

  ngOnInit() {
    this.manager = localStorage.getItem("manager");
    if (this.manager == "1") {
      document.getElementById("isManager").style.display = "none";
    }
  }

  onChange(event) {
    var elems = document.querySelectorAll("mat-select");
    //var instances = M.FormSelect.init(elems, options);
    var filterValues = {
      status: elems[0]["innerText"],
      manager: elems[1]["innerText"]
      //manager: "john"
    };

    this.dialogRef.close(filterValues);
  }
}
