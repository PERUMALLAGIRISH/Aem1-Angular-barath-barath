import { Component, OnInit, ViewChild } from "@angular/core";
import {
  MatDialog,
  MatDialogRef,
  MatDialogConfig,
  MatTableDataSource
} from "@angular/material";
import { RequestService } from "src/app/request/request.service";
import { Request } from "./request";
import { FilterComponent } from "src/app/filter/filter.component";

@Component({
  selector: "app-request",
  templateUrl: "./request.component.html",
  styleUrls: ["./request.component.css"]
})
export class RequestComponent implements OnInit {
  displayedColumns: string[] = [
    "requestId",
    "fname",
    "lname",
    "date",
    "status",
    "manager",
    "country",
    "state",
    "zipcode",
    "email"
  ];
  dataSource: MatTableDataSource<Request>;

  constructor(
    private RequestService: RequestService,
    private dialog: MatDialog
  ) {
    this.RequestService.getList().subscribe(data => {
      const users = data;
      //console.log(users);
      this.dataSource = new MatTableDataSource(users);
    });
  }

  ngOnInit() {}

  applyFilter(filterValue: string) {
    console.log(filterValue);
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  onChange(event) {
    let filterValue: string = event.source.value;
    console.log(filterValue);
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  openDialog() {
    const dialogConfig = new MatDialogConfig();
    const dialog = this.dialog.open(FilterComponent, dialogConfig);
    dialog.afterClosed().subscribe(data => {
      this.dataSource.filter = data;
    });

    return dialog;
  }
}
