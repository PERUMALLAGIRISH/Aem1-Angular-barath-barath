export interface Request {
  firstname: string;
  lastname: string;
  email: string;
  status: string;
}
