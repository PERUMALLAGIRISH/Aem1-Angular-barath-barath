import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"]
})
export class LoginComponent implements OnInit {
  constructor(
    private formBuilder: FormBuilder,
    public toastr: ToastrService,
    private router: Router
  ) {}
  loginForm: FormGroup;
  submitted = false;
  alphaNumaric = "^[A-Za-z0-9_]{3,50}$";
  email = "^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$";
  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      emailAddress: ["", [Validators.required, Validators.pattern(this.email)]],
      password: [
        "",
        [Validators.required, Validators.pattern(this.alphaNumaric)]
      ]
    });
  }

  public hasError = (controlName: string, errorName: string) => {
    return this.loginForm.controls[controlName].hasError(errorName);
  };

  loginAdmin() {
    this.submitted = true;

    //stop here if form is invalid
    if (this.loginForm.invalid) {
      return;
    }
    console.log(this.loginForm.value);
    this.toastr.success("Welcome", "You Have successfully Registered");
    this.router.navigate(["/", "request"]);
  }
}
