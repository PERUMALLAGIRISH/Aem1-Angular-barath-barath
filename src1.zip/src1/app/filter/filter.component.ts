import { Component, OnInit } from "@angular/core";
import { MatDialogRef } from "@angular/material";

@Component({
  selector: "app-filter",
  templateUrl: "./filter.component.html",
  styleUrls: ["./filter.component.css"]
})
export class FilterComponent implements OnInit {
  constructor(public dialogRef: MatDialogRef<FilterComponent>) {}

  ngOnInit() {}
  onChange(event) {
    let filterValue: string = event.source.value;
    console.log(filterValue);
    this.dialogRef.close(filterValue.trim().toLowerCase());
    //this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  // close() {
  //   this.dialogRef.close();
  // }
}
