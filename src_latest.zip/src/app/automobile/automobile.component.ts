import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ToastrService } from "ngx-toastr";
import { Router } from "@angular/router";
import { MessageService } from "src/app/services/message.service";

@Component({
  selector: "app-automobile",
  templateUrl: "./automobile.component.html",
  styleUrls: ["./automobile.component.css"]
})
export class AutomobileComponent implements OnInit {
  automobileForm: FormGroup;
  submitted = false;
  alphaNumaric = "^[A-Za-z0-9_]{3,50}$";
  email = "^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$";
  numberonlyPhone = "^[0-9]{10,10}$";
  today = new Date();
  emailValidationCount: number = 0;
  FnameValidationCount: number = 0;
  LnameValidationCount: number = 0;
  Message;

  constructor(
    private formBuilder: FormBuilder,
    public toastr: ToastrService,
    private router: Router,
    private MessageService: MessageService
  ) {
    this.MessageService.getMessage().subscribe(data => {
      this.Message = data;
    });
  }

  ngOnInit() {
    this.automobileForm = this.formBuilder.group({
      nameOfExistingFirm: ["", [Validators.required]],
      completeAddress: ["", [Validators.required]],
      city: [""],
      contactPerson: [""],
      phoneNumbers: [""],
      businessAppliedFor: [""],
      territoryAppliedFor: [""],
      turnOver: [""],
      currentLinesOfBusiness: [""],
      expectedProjectionForTMLBusiness: [""],
      firstYear: [""],
      secondYear: [""],
      thirdYear: [""],
      territoryAppliedForPersonalInfo: [""],
      nameOfMainApplicant: [""],
      dobMainApplicant: [""],
      nameOfExistingFirmPersonalInfo: [""],
      completeAddressResidence: [""],
      completeAddressOffice: [""],
      addressForCorrespondence: [""],
      primaryCellNumber: [""],
      alternateCellNumber: [""],
      landLine: [""],
      emailAddress: ["", [Validators.required, Validators.pattern(this.email)]],
      website: [""],
      photographOfMainApplicant: [""],
      name: [""],
      relationshipWithMainApplicant: [""],
      presetAge: [""],
      HighestQualification: [""]
    });
  }

  public hasError = (controlName: string, errorName: string) => {
    return this.automobileForm.controls[controlName].hasError(errorName);
  };

  get getFormValue() {
    return this.automobileForm.controls;
  }
  chatValidateEmail() {
    var emailAddress = (<HTMLInputElement>(
      document.getElementById("emailAddress")
    )).value;

    if (emailAddress.match(this.email)) {
      return true;
    } else {
      this.emailValidationCount++;
      if (this.emailValidationCount === 2) {
        let error = this.Message["onBoard"]["errorMessage"];
        this.toastr.error(error["emailSubTitle"], error["emailTitle"]);
        return false;
      }
    }
  }
  chatValidateFname() {
    var firstName = (<HTMLInputElement>document.getElementById("firstName"))
      .value;

    if (firstName.match(this.alphaNumaric)) {
      return true;
    } else {
      this.FnameValidationCount++;
      if (this.FnameValidationCount >= 2) {
        let error = this.Message["onBoard"]["errorMessage"];
        this.toastr.error(error["firstNameSubTitle"], error["firstNameTitle"]);
        return false;
      }
    }
  }

  applicationSummary() {
    this.submitted = true;

    //stop here if form is invalid
    if (this.automobileForm.invalid) {
      document.body.scrollTop = 0; // For Safari
      document.documentElement.scrollTop = 0;
      return;
    }

    let success = this.Message["onBoard"]["successMessage"];
    this.toastr.success(success.SubTitle, success.Title);
  }
}
