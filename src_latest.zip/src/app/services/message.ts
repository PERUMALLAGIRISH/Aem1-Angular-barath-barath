export interface Message {
  message: {};
}
