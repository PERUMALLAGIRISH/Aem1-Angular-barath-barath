import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Message } from "./message";
import { Observable } from "../../../node_modules/rxjs";

@Injectable({
  providedIn: "root"
})
export class MessageService {
  private cartUrl = "./assets/json/message.json";
  constructor(private httpService: HttpClient) {}

  getMessage(): Observable<Message[]> {
    return this.httpService.get<Message[]>(this.cartUrl);
  }
}
