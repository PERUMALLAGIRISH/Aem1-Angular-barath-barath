import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { MatCardModule } from "@angular/material/card";
import { ReactiveFormsModule } from "@angular/forms";
import { ToastrModule } from "ngx-toastr";
import {
  MatInputModule,
  MatFormFieldModule,
  MatButtonModule,
  MatRadioModule,
  MatDatepickerModule,
  MatNativeDateModule,
  MatSelectModule,
  MatTableModule,
  MatDialogModule,
  MatPaginatorModule,
  MatToolbarModule,
  MatIconModule,
  MatCheckboxModule,
  MatSliderModule
} from "@angular/material";
import { SignaturePadModule } from "angular2-signaturepad";
import { HttpClientModule } from "@angular/common/http";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { HeaderComponent } from "./header/header.component";
import { FooterComponent } from "./footer/footer.component";
import { HomeComponent } from "./home/home.component";
import { LoginComponent } from "./login/login.component";
import { RequestComponent } from "./request/request.component";
import { ManagerComponent } from "./manager/manager.component";
import { FilterComponent } from "./filter/filter.component";
import { MatSidenavModule } from "@angular/material";
import { UserDetailComponent } from "./user-detail/user-detail.component";
import { RetailComponent } from "./retail/retail.component";
import { InsuranceComponent } from "./insurance/insurance.component";
import { AutomobileComponent } from "./automobile/automobile.component";

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    LoginComponent,
    RequestComponent,
    ManagerComponent,
    FilterComponent,
    UserDetailComponent,
    RetailComponent,
    InsuranceComponent,
    AutomobileComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatCardModule,
    ReactiveFormsModule,
    ToastrModule.forRoot(),
    MatFormFieldModule,
    HttpClientModule,
    MatInputModule,
    MatButtonModule,
    MatRadioModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSelectModule,
    SignaturePadModule,
    MatTableModule,
    MatDialogModule,
    MatPaginatorModule,
    MatSidenavModule,
    MatToolbarModule,
    MatIconModule,
    MatCheckboxModule,
    MatSliderModule
  ],
  providers: [],
  bootstrap: [AppComponent],
  entryComponents: [FilterComponent]
})
export class AppModule {}
