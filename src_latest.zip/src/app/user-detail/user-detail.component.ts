import { Component, OnInit } from "@angular/core";
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl
} from "@angular/forms";
import { MatDialogRef } from "@angular/material";

@Component({
  selector: "app-user-detail",
  templateUrl: "./user-detail.component.html",
  styleUrls: ["./user-detail.component.css"]
})
export class UserDetailComponent implements OnInit {
  managerForm: FormGroup;
  submitted = false;
  alphaNumaric = "^[A-Za-z0-9_]{3,50}$";

  firstName = "Karvannan";
  middleName = "";
  lastName = "Pandurangan";
  dob = "6/5/1992";
  mobileNumber = "9632587415";
  marital = "1";
  country = "1";
  address = "105 - Main Street";
  city = "Chennai";
  zipCode = "632584";
  landline = "444 333";
  company = "Tech-M";
  numberOfDependencies = "4";
  ctc = "3";
  TypeOfEmployment = "3";
  TakeHome = "450000";
  relationshipBank = "2";
  date = new Date();

  constructor(
    private formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<UserDetailComponent>
  ) {}

  ngOnInit() {
    this.managerForm = this.formBuilder.group({
      feedback: [
        "",
        [Validators.required, Validators.pattern(this.alphaNumaric)]
      ]
    });
  }

  public hasError = (controlName: string, errorName: string) => {
    return this.managerForm.controls[controlName].hasError(errorName);
  };

  get getFormValue() {
    return this.managerForm.controls;
  }
  registerUser() {
    this.submitted = true;

    //stop here if form is invalid
    if (this.managerForm.invalid) {
      return;
    }
    this.dialogRef.close();
  }
  drawStart() {
    console.log("begin drawing");
  }
}
