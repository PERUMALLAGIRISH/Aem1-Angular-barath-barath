import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ToastrService } from "ngx-toastr";
import { Router } from "@angular/router";
import { MessageService } from "src/app/services/message.service";

@Component({
  selector: "app-insurance",
  templateUrl: "./insurance.component.html",
  styleUrls: ["./insurance.component.css"]
})
export class InsuranceComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
  alphaNumaric = "^[A-Za-z0-9_]{3,50}$";
  email = "^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$";
  numberonlyPhone = "^[0-9]{10,10}$";
  today = new Date();
  emailValidationCount: number = 0;
  FnameValidationCount: number = 0;
  LnameValidationCount: number = 0;
  Message;

  constructor(
    private formBuilder: FormBuilder,
    public toastr: ToastrService,
    private router: Router,
    private MessageService: MessageService
  ) {
    this.MessageService.getMessage().subscribe(data => {
      this.Message = data;
    });
  }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      name: ["", [Validators.required, Validators.pattern(this.alphaNumaric)]],
      lastName: [
        "",
        [Validators.required, Validators.pattern(this.alphaNumaric)]
      ],
      emailAddress: ["", [Validators.required, Validators.pattern(this.email)]],
      mobileNumber: [""],
      city: [""],
      state: [""],
      zipcode: [""],
      address: [""],
      addressTwo: [""],
      nameOfEmployer: [""],
      dob: [""],
      doh: [""],
      planNumbers: [""],
      eveningPhone: [""],
      taxId: [""],
      socialSecurity: [""],
      empCityState: [""],
      EmpZipcode: [""],
      nameOfSite: [""],
      invFundCode: [""],
      fundName: [""]
    });
  }

  public hasError = (controlName: string, errorName: string) => {
    return this.registerForm.controls[controlName].hasError(errorName);
  };

  get getFormValue() {
    return this.registerForm.controls;
  }
  chatValidateEmail() {
    var emailAddress = (<HTMLInputElement>(
      document.getElementById("emailAddress")
    )).value;

    if (emailAddress.match(this.email)) {
      return true;
    } else {
      this.emailValidationCount++;
      if (this.emailValidationCount === 2) {
        let error = this.Message["onBoard"]["errorMessage"];
        this.toastr.error(error["emailSubTitle"], error["emailTitle"]);
        return false;
      }
    }
  }
  chatValidateFname() {
    var firstName = (<HTMLInputElement>document.getElementById("firstName"))
      .value;

    if (firstName.match(this.alphaNumaric)) {
      return true;
    } else {
      this.FnameValidationCount++;
      if (this.FnameValidationCount >= 2) {
        let error = this.Message["onBoard"]["errorMessage"];
        this.toastr.error(error["firstNameSubTitle"], error["firstNameTitle"]);
        return false;
      }
    }
  }

  registerUser() {
    this.submitted = true;

    //stop here if form is invalid
    if (this.registerForm.invalid) {
      document.body.scrollTop = 0; // For Safari
      document.documentElement.scrollTop = 0;
      return;
    }

    let success = this.Message["onBoard"]["successMessage"];
    this.toastr.success(success.SubTitle, success.Title);
  }
}
