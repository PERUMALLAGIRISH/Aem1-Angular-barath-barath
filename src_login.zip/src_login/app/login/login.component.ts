import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"]
})
export class LoginComponent implements OnInit {
  errorMsg: string;
  constructor(private router: Router) {}

  ngOnInit() {}

  creteLogin(loginForm) {
    if (loginForm.email == "test@gmail.com" && loginForm.pwd == "test") {
      this.router.navigate(["list"]);
    } else {
      this.errorMsg = "You have entered an invalid username or password";
    }
  }
}
