import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Request } from "./request";
import { Observable } from "../../../node_modules/rxjs";

@Injectable({
  providedIn: "root"
})
export class RequestService {
  private cartUrl = "./assets/json/list.json";
  constructor(private httpService: HttpClient) {}

  getList(): Observable<Request[]> {
    return this.httpService.get<Request[]>(this.cartUrl);
  }
}
