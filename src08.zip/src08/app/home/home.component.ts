import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { SignaturePad } from "angular2-signaturepad/signature-pad";
import { Router } from "@angular/router";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.css"]
})
export class HomeComponent implements OnInit {
  @ViewChild(SignaturePad) signaturePad: SignaturePad;
  private signaturePadOptions: Object = {
    minWidth: 5,
    canvasWidth: 1050,
    canvasHeight: 150
  };
  registerForm: FormGroup;
  submitted = false;
  alphaNumaric = "^[A-Za-z0-9_]{3,50}$";
  email = "^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$";
  numberonlyPhone = "^[0-9]{10,10}$";
  today = new Date();

  constructor(
    private formBuilder: FormBuilder,
    public toastr: ToastrService,
    private router: Router
  ) {}

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstName: [
        "",
        [Validators.required, Validators.pattern(this.alphaNumaric)]
      ],
      lastName: [
        "",
        [Validators.required, Validators.pattern(this.alphaNumaric)]
      ],
      emailAddress: ["", [Validators.required, Validators.pattern(this.email)]],
      mobileNumber: [""],
      middleName: [""],
      address: [""],
      marital: [""],
      dob: [""],
      zipcode: [""],
      city: [""],
      landline: [""],
      numberOfDeps: [""],
      company: [""],
      typeOfEmp: [""],
      ctc: [""],
      relationship: [""],
      date: [""]
    });
  }

  public hasError = (controlName: string, errorName: string) => {
    return this.registerForm.controls[controlName].hasError(errorName);
  };

  get getFormValue() {
    return this.registerForm.controls;
  }
  registerUser() {
    this.submitted = true;

    //stop here if form is invalid
    if (this.registerForm.invalid) {
      document.body.scrollTop = 0; // For Safari
      document.documentElement.scrollTop = 0;
      return;
    }
    console.log(this.registerForm.value);
    this.toastr.success("Welcome", "You Have successfully Registered");
  }

  ngAfterViewInit() {
    this.signaturePad.set("minWidth", 5);
    this.signaturePad.clear();
  }

  drawComplete() {
    console.log(this.signaturePad.toDataURL());
  }

  onClearHandler() {
    this.signaturePad.clear();
  }

  drawStart() {
    console.log("begin drawing");
  }
}
