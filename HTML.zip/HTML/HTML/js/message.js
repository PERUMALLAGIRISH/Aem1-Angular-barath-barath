var welcome = {};
var video = {};

var techmUser = true; // for disable false

//Welcome Page
welcome.title = "Welcome To Tech Mahindra";
welcome.subTitle = "Sample Text Data";
welcome.ListTitle = "Onboard,Dashboard,Alexa";

// Video Page
video.success = "Thank You for watching";
